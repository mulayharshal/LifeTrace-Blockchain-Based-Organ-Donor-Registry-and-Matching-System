package com.lifetrace.backend.dto;

import lombok.Data;

import java.util.List;

@Data
public class RegisterOrganRequest {

    private Long donorId;

    // MULTIPLE organs instead of single
    private List<String> organTypes;

    private String bloodGroup;

    private String condition;

    // NEW fields for matching
    private String location;        // Pune / Mumbai
    private String urgencyLevel;    // LOW / MEDIUM / HIGH
}