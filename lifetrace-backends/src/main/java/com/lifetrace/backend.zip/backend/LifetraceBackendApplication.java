package com.lifetrace.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LifetraceBackendApplication {


	public static void main(String[] args) {
		SpringApplication.run(LifetraceBackendApplication.class, args);
	}
}