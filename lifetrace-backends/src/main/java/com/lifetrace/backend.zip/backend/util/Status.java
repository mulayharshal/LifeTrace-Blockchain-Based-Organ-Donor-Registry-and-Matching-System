package com.lifetrace.backend.util;

public enum Status {
	SUCCESS,FAIL,EXCEPTION

}
