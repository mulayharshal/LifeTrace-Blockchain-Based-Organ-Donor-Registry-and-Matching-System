package com.lifetrace.backend.dto;

import lombok.Data;

@Data
public class OrganRequestItem {
    private String organType;
    private String condition;
}
